

package com.thbs.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.thbs.demo.model.Passenger;
import com.thbs.demo.model.Train;
public interface TrainRepository extends JpaRepository<Train, Integer> {

	 

}




	

